import mysql.connector
class Database:
    def __init__(self):
        self.conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="Glstn825136!",
            database="blood_database"
        )
        self.cursor = self.conn.cursor(dictionary=True)
    def fetch_query(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()
    def add_donor(self, name, donor_id, age, blood_group, disease=None):
        query = "INSERT INTO donor (name, ID, age, blood_group, disease) VALUES (%s, %s, %s, %s, %s)"
        self.cursor.execute(query, (name, donor_id, age, blood_group, disease))
        self.conn.commit()
    def delete_donor(self, donor_id):
        query = "DELETE FROM donor WHERE ID = %s"
        self.cursor.execute(query, (donor_id,))
        self.conn.commit()
    def update_donor(self, donor_id, name=None, age=None, blood_group=None, disease=None):
        query = "UPDATE donor SET "
        updates = []
        values = []
        if name:
            updates.append("name = %s")
            values.append(name)
        if age:
            updates.append("age = %s")
            values.append(age)
        if blood_group:
            updates.append("blood_group = %s")
            values.append(blood_group)
        if disease:
            updates.append("disease = %s")
            values.append(disease)
        query += ", ".join(updates) + " WHERE ID = %s"
        values.append(donor_id)
        self.cursor.execute(query, values)
        self.conn.commit()
    def add_patient(self, patient_id, name, address, need_bloodgroup, host_name):
        query = "INSERT INTO patient (ID, name, address, need_bloodgroup, host_name) VALUES (%s, %s, %s, %s, %s)"
        self.cursor.execute(query, (patient_id, name, address, need_bloodgroup, host_name))
        self.conn.commit()
    def delete_patient(self, patient_id):
        query = "DELETE FROM patient WHERE ID = %s"
        self.cursor.execute(query, (patient_id,))
        self.conn.commit()
    def close_connection(self):
        self.conn.close()
