from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QTabWidget, QWidget, QTableWidget, QTableWidgetItem, QPushButton, QLabel, QComboBox, QDateTimeEdit, QMessageBox, QDialog, QInputDialog
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QDateTime, Qt
from database import Database
from login import LoginWindow
import os

class DoctorPhotoViewer(QDialog):
    def __init__(self, doctor_id, db):
        super().__init__()
        self.setWindowTitle("Doctor Photo")
        self.setGeometry(300, 200, 400, 400)

        layout = QVBoxLayout()
        self.setLayout(layout)

        doctor = db.fetch_query(f"SELECT name, photo_path FROM doctor WHERE ID = '{doctor_id}'")
        if doctor:
            doctor = doctor[0]
            name_label = QLabel(f"Doctor: {doctor['name']}")
            layout.addWidget(name_label)

            if doctor['photo_path']:
                if doctor['photo_path'].startswith('images/'):
                    photo_path = doctor['photo_path']
                else:
                    photo_path = os.path.join('images', doctor['photo_path'])

                if os.path.exists(photo_path):
                    pixmap = QPixmap(photo_path)
                    photo_label = QLabel()
                    photo_label.setPixmap(pixmap.scaled(300, 300, Qt.KeepAspectRatio))
                    layout.addWidget(photo_label)
                else:
                    layout.addWidget(QLabel(f"Photo file not found at: {photo_path}"))
            else:
                layout.addWidget(QLabel("No photo available."))
        else:
            QMessageBox.warning(self, "Error", "Doctor not found!")

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Blood Donation Database")
        self.setGeometry(100, 100, 1200, 800)
        self.db = Database()
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)
        self.tabs = QTabWidget()
        self.layout.addWidget(self.tabs)

        self.create_tabs()

    def create_tabs(self):
        self.create_tab("Donors", self.create_donor_table, self.donor_crud)
        self.create_tab("Patients", self.create_patient_table, self.patient_crud)
        self.create_tab("Doctors", self.create_doctor_table, self.doctor_crud)
        self.create_tab("Nurses", self.create_nurse_table, self.nurse_crud)
        self.create_tab("Hospitals", self.create_hospital_table, self.hospital_crud)
        self.create_tab("Appointments", self.create_appointment_table, self.appointment_crud)
        self.create_appointment_tab()

    def create_tab(self, title, table_function, crud_function):
        tab = QWidget()
        self.tabs.addTab(tab, title)
        layout = QVBoxLayout()
        tab.setLayout(layout)
        table = table_function()
        crud_buttons = crud_function(table)
        layout.addWidget(table)
        for button in crud_buttons:
            button.setStyleSheet("background-color: darkred; color: white; font-weight: bold;")
            layout.addWidget(button)

    def create_generic_table(self, headers):
        table = QTableWidget()
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setStyleSheet("QHeaderView::section { background-color: darkred; color: white; }")
        table.setAlternatingRowColors(True)
        return table

    def create_donor_table(self):
        return self.create_generic_table(["ID", "Name", "Blood Group", "Age", "Disease"])

    def create_patient_table(self):
        return self.create_generic_table(["ID", "Name", "Address", "Need Blood Group", "Host Name"])

    def create_doctor_table(self):
        return self.create_generic_table(["ID", "Name", "Shift", "Vigil"])

    def create_nurse_table(self):
        return self.create_generic_table(["ID", "Name", "Shift", "Vigil"])

    def create_hospital_table(self):
        return self.create_generic_table(["Host Name", "Address", "Capacity", "Dept Host", "Block"])

    def create_appointment_table(self):
        return self.create_generic_table(["Block", "Time", "Date", "Doctor", "Patient", "Hospital"])

    def donor_crud(self, table):
        def list_donors():
            donors = self.db.fetch_query("SELECT * FROM donor")
            table.setRowCount(len(donors))
            table.setColumnCount(5)
            table.setHorizontalHeaderLabels(["ID", "Name", "Blood Group", "Age", "Disease"])
            for row_index, donor in enumerate(donors):
                for col_index, key in enumerate(["ID", "name", "blood_group", "age", "disease"]):
                    table.setItem(row_index, col_index, QTableWidgetItem(str(donor[key])))

        def compatible_donors():
            compatible = self.db.fetch_query(
                """
                SELECT d.name AS Donor, p.name AS Recipient
                FROM donor d
                JOIN patient p ON d.blood_group = p.need_bloodgroup
                """
            )
            table.setRowCount(len(compatible))
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["Donor", "Recipient"])
            for row_index, pair in enumerate(compatible):
                table.setItem(row_index, 0, QTableWidgetItem(pair['Donor']))
                table.setItem(row_index, 1, QTableWidgetItem(pair['Recipient']))

        def add_donor():
            name, ok = QInputDialog.getText(self, "Add Donor", "Name:")
            if not ok or not name:
                return
            donor_id, ok = QInputDialog.getText(self, "Add Donor", "ID:")
            if not ok or not donor_id:
                return
            age, ok = QInputDialog.getInt(self, "Add Donor", "Age:")
            if not ok:
                return
            blood_group, ok = QInputDialog.getText(self, "Add Donor", "Blood Group:")
            if not ok or not blood_group:
                return
            disease, ok = QInputDialog.getText(self, "Add Donor", "Disease (optional):")
            if not ok:
                disease = None

            try:
                self.db.add_donor(name=name, donor_id=donor_id, age=age, blood_group=blood_group, disease=disease)
                QMessageBox.information(self, "Success", "Donor successfully added.")
                list_donors()
            except Exception as e:
                QMessageBox.critical(self, "Error", f"An error occurred while adding donor: {e}")

        list_button = QPushButton("List Donors")
        list_button.clicked.connect(list_donors)

        add_button = QPushButton("Add Donor")
        add_button.clicked.connect(add_donor)

        compatible_button = QPushButton("Compatible Donors")
        compatible_button.clicked.connect(compatible_donors)

        return [list_button, add_button, compatible_button]

    def patient_crud(self, table):
        def list_patients():
            patients = self.db.fetch_query("SELECT * FROM patient")
            table.setRowCount(len(patients))
            for row_index, patient in enumerate(patients):
                for col_index, key in enumerate(["ID", "name", "address", "need_bloodgroup", "host_name"]):
                    table.setItem(row_index, col_index, QTableWidgetItem(str(patient[key])))

        list_button = QPushButton("List Patients")
        list_button.clicked.connect(list_patients)
        return [list_button]

    def doctor_crud(self, table):
        def list_doctors():
            doctors = self.db.fetch_query("SELECT * FROM doctor")
            table.setRowCount(len(doctors))
            for row_index, doctor in enumerate(doctors):
                for col_index, key in enumerate(["ID", "name", "shift", "vigil"]):
                    table.setItem(row_index, col_index, QTableWidgetItem(str(doctor[key])))

        list_button = QPushButton("List Doctors")
        list_button.clicked.connect(list_doctors)

        def view_doctor_photo():
            selected_row = table.currentRow()
            if selected_row == -1:
                QMessageBox.warning(self, "Selection Error", "Please select a doctor to view photo.")
                return

            doctor_id = table.item(selected_row, 0).text()
            photo_dialog = DoctorPhotoViewer(doctor_id, self.db)
            photo_dialog.exec_()

        photo_button = QPushButton("View Photo")
        photo_button.clicked.connect(view_doctor_photo)
        return [list_button, photo_button]

    def nurse_crud(self, table):
        def list_nurses():
            nurses = self.db.fetch_query("SELECT * FROM nurse")
            table.setRowCount(len(nurses))
            for row_index, nurse in enumerate(nurses):
                for col_index, key in enumerate(["ID", "name", "shift", "vigil"]):
                    table.setItem(row_index, col_index, QTableWidgetItem(str(nurse[key])))

        list_button = QPushButton("List Nurses")
        list_button.clicked.connect(list_nurses)
        return [list_button]

    def hospital_crud(self, table):
        def list_hospitals():
            hospitals = self.db.fetch_query("SELECT * FROM hospital")
            table.setRowCount(len(hospitals))
            for row_index, hospital in enumerate(hospitals):
                for col_index, key in enumerate(["host_name", "address", "capacity", "dept_host", "block"]):
                    table.setItem(row_index, col_index, QTableWidgetItem(str(hospital[key])))

        list_button = QPushButton("List Hospitals")
        list_button.clicked.connect(list_hospitals)
        return [list_button]

    def appointment_crud(self, table):
        def list_appointments():
            appointments = self.db.fetch_query(
                """
                SELECT 
                    a.block, a.time, a.date, 
                    COALESCE(d.name, 'Unknown') AS doctor, 
                    COALESCE(p.name, 'Unknown') AS patient, 
                    COALESCE(h.host_name, 'Unknown') AS hospital
                FROM appointment a
                LEFT JOIN doctor d ON a.doctor_id = d.ID
                LEFT JOIN patient p ON a.patient_id = p.ID
                LEFT JOIN hospital h ON a.hospital_id = h.host_name
                """
            )
            table.setRowCount(len(appointments))
            table.setColumnCount(6)
            table.setHorizontalHeaderLabels(["Block", "Time", "Date", "Doctor", "Patient", "Hospital"])
            for row_index, appointment in enumerate(appointments):
                for col_index, key in enumerate(["block", "time", "date", "doctor", "patient", "hospital"]):
                    table.setItem(row_index, col_index, QTableWidgetItem(str(appointment[key])))

        list_button = QPushButton("List Appointments")
        list_button.clicked.connect(list_appointments)
        return [list_button]

    def create_appointment_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        patient_label = QLabel("Select Patient:")
        layout.addWidget(patient_label)

        self.patient_dropdown = QComboBox()
        patients = self.db.fetch_query("SELECT ID, name FROM patient")
        for patient in patients:
            self.patient_dropdown.addItem(patient['name'], patient['ID'])
        layout.addWidget(self.patient_dropdown)

        doctor_label = QLabel("Select Doctor:")
        layout.addWidget(doctor_label)

        self.doctor_dropdown = QComboBox()
        doctors = self.db.fetch_query("SELECT ID, name FROM doctor")
        for doctor in doctors:
            self.doctor_dropdown.addItem(doctor['name'], doctor['ID'])
        layout.addWidget(self.doctor_dropdown)

        hospital_label = QLabel("Select Hospital:")
        layout.addWidget(hospital_label)

        self.hospital_dropdown = QComboBox()
        hospitals = self.db.fetch_query("SELECT host_name, address FROM hospital")
        for hospital in hospitals:
            self.hospital_dropdown.addItem(hospital['host_name'], hospital['host_name'])
        layout.addWidget(self.hospital_dropdown)

        time_label = QLabel("Select Appointment Time:")
        layout.addWidget(time_label)

        self.time_input = QDateTimeEdit()
        self.time_input.setCalendarPopup(True)
        self.time_input.setMinimumDateTime(QDateTime.currentDateTime())
        layout.addWidget(self.time_input)

        book_button = QPushButton("Book Appointment")
        book_button.setStyleSheet("background-color: darkred; color: white; font-weight: bold;")
        book_button.clicked.connect(self.book_appointment)
        layout.addWidget(book_button)

        tab.setLayout(layout)
        self.tabs.addTab(tab, "Book Appointment")

    def book_appointment(self):
        patient_id = self.patient_dropdown.currentData()
        doctor_id = self.doctor_dropdown.currentData()
        hospital_id = self.hospital_dropdown.currentText()
        appointment_time = self.time_input.dateTime()

        if not patient_id:
            QMessageBox.warning(self, "Missing Selection", "Please select a patient.")
            return

        if not doctor_id:
            QMessageBox.warning(self, "Missing Selection", "Please select a doctor.")
            return

        if not hospital_id:
            QMessageBox.warning(self, "Missing Selection", "Please select a hospital.")
            return

        current_time = QDateTime.currentDateTime()
        if appointment_time < current_time:
            QMessageBox.warning(self, "Invalid Date", "You cannot book an appointment in the past.")
            return

        query_check = """
            SELECT * FROM appointment
            WHERE date = %s AND time = %s AND hospital_id = %s
        """
        self.db.cursor.execute(query_check, (appointment_time.toString("yyyy-MM-dd"), appointment_time.toString("HH:mm:ss"), hospital_id))
        conflict = self.db.cursor.fetchone()

        if conflict:
            QMessageBox.warning(self, "Conflict", "An appointment already exists for the selected time and hospital.")
            return

        query_insert = """
            INSERT INTO appointment (block, date, time, hospital_id, patient_id, doctor_id)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        self.db.cursor.execute(query_insert, ("A3", appointment_time.toString("yyyy-MM-dd"), appointment_time.toString("HH:mm:ss"), hospital_id, patient_id, doctor_id))
        self.db.conn.commit()

        QMessageBox.information(self, "Success", "Your appointment has been booked successfully!")

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)

    login_window = LoginWindow()
    if login_window.exec_() == QDialog.Accepted:
        main_window = MainWindow()
        main_window.show()
        sys.exit(app.exec_())
